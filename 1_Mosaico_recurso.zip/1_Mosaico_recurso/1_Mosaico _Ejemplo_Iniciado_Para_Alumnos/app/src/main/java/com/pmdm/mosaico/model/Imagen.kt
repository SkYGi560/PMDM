package com.pmdm.mosaico.model

data class Imagen(val url: String = "")