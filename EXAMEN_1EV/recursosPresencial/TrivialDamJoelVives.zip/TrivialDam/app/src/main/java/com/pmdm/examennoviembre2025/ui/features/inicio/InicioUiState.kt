package com.pmdm.examennoviembre2025.ui.features.inicio

data class InicioUiState (
    val estaCategoriaSeleccionada: Boolean = false,
    val jugadorNombre: String = "",
    val numeroPreguntas: Float = 10f
)