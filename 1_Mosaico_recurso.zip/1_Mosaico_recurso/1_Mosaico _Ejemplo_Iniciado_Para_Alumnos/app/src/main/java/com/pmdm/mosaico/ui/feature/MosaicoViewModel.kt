package com.pmdm.mosaico.ui.feature

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.pmdm.mosaico.data.ImagenRepository

class MosaicoViewModel : ViewModel() {
    var mosaicoUIState : MosaicoUIState? by mutableStateOf(null)
        private set

    private val imagenRepository : ImagenRepository = ImagenRepository()

    init {
        mosaicoUIState = MosaicoUIState(
            imagenes = imagenRepository.getImagenes(),
            posicionSlider = 2f
        )
    }

    fun onMosaicoEvent(e : MosaicoEvent ) {
        when (e) {
            is MosaicoEvent.onChangePosicionSlider -> {
                mosaicoUIState?.let {
                    mosaicoUIState = it.copy(posicionSlider = e.posicionSlider)
                }
            }
        }
    }

}