package com.pmdm.mosaico.ui.feature

sealed interface MosaicoEvent {
    data class onChangePosicionSlider(val posicionSlider: Float) : MosaicoEvent
}
