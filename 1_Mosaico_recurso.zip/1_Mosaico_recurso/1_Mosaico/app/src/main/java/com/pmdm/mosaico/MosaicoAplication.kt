package com.pmdm.mosaico

import android.app.Application

class MosaicoAplication:Application() {
}