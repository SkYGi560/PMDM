package com.pmdm.mosaico.ui.feature

import com.pmdm.mosaico.model.Imagen

data class MosaicoUIState (
    val imagenes: List<Imagen>,
    val posicionSlider: Float
)

