package com.pmdm.mosaico.ui.feature

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.pmdm.mosaico.data.ImagenRepository

class MosaicoViewModel : ViewModel() {

    val imagenRepository = ImagenRepository()
    var mosaicoUIState by mutableStateOf(
        MosaicoUIState(imagenes = imagenRepository.getImagenes(), posicionSlider = 4f)
    )


    fun onMosaicoEvent(evento: MosaicoEvent) {
        when(evento)
        {
            is MosaicoEvent.onChangePosicionSlider -> {
                mosaicoUIState = mosaicoUIState.copy(posicionSlider = evento.posion)
            }
        }

    }

}