package com.pmdm.mosaico.data

import com.pmdm.mosaico.data.mock.imagen.ImagenMock
import com.pmdm.mosaico.models.Imagen

fun ImagenMock.toImagen() = Imagen(url)
fun List<ImagenMock>.toImagenes() = this.map { it.toImagen() }