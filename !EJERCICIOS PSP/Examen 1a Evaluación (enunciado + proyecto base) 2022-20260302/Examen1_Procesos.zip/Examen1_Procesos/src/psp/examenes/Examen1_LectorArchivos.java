package psp.examenes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author VicenteMartínez
 */
public class Examen1_LectorArchivos {

    private static String fileName;
    private static int returnNumber;

    public static void main(String[] args) {
        // Comprobación de argumentos
        if (args.length != 2) {
            System.err.println("Número de argumentos insuficiente");
            System.exit(returnNumber + 1);
        }

        // Recogida de argumentos
        fileName = args[0];
        try {
            returnNumber = Integer.parseInt(args[1]);
        } catch (NumberFormatException nfe) {
            System.err.println("Error en el formato de los parámetros. " + nfe.getLocalizedMessage());
            nfe.printStackTrace();
            System.exit(returnNumber + 1);
        }

        // Leemos el archivo
        File f = new File(fileName);
        if (!f.exists() || !f.isFile()) {
            System.err.println("No se puede acceder al archivo indicado.");
            System.exit(returnNumber + 2);
        }

        // Inicializamos contadores
        int nLineas = 0, nPalabras = 0, nCaracteres = 0;
        try {
            String linea;
            BufferedReader br = new BufferedReader(new FileReader(f));
            while ((linea = br.readLine()) != null) {
                nLineas++;
                nPalabras += linea.split("\\s").length;
                nCaracteres += linea.length();
                System.out.println(linea.substring(linea.lastIndexOf(" ")));
            }
        } catch (IOException ex) {
            System.err.println("Error en la lectura del archivo. " + ex.getLocalizedMessage());
            ex.printStackTrace();
            System.exit(returnNumber + 3);
        }
        
        // Mostramos resumen
        System.out.println("L: " + nLineas);
        System.out.println("P: " + nPalabras);
        System.out.println("C: " + nCaracteres);
        System.err.println(returnNumber);
        
        // Finaliza el ejercicio correctamente
        System.exit(0);
    }
}
