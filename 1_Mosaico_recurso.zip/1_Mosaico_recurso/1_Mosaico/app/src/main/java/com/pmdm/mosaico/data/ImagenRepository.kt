package com.pmdm.mosaico.data

import com.pmdm.mosaico.data.mock.imagen.ImagenDaoMock
import com.pmdm.mosaico.models.Imagen

class ImagenRepository {
    var imagenDaoMock = ImagenDaoMock()

    fun getImagenes(): List<Imagen> = imagenDaoMock.getImagenes().toImagenes()
}