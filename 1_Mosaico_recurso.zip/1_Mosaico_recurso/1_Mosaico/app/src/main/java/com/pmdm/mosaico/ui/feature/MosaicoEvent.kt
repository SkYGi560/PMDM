package com.pmdm.mosaico.ui.feature

sealed interface MosaicoEvent {
    class onChangePosicionSlider(val posion: Float): MosaicoEvent
}
