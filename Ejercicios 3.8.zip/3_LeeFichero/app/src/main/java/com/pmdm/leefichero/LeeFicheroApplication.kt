package com.pmdm.leefichero

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class LeeFicheroApplication : Application()