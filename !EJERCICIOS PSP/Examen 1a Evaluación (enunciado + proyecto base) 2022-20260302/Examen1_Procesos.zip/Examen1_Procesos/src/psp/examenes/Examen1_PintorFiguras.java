package psp.examenes;

import java.util.Scanner;

/**
 *
 * @author VicenteMartínez
 */
public class Examen1_PintorFiguras {

    private static void cuadrado(int lado) {
        for (int i = 0; i < lado; i++) {
            for (int j = 0; j < lado; j++) {                
                System.out.print("#");
            }
            System.out.println();
        }
    }

    private static void triangulo(int altura) {
        for (int i = 1; i <= altura; i++) {
            for (int j = altura - i; j < altura; j++) {
                System.out.print("#");
            }
            System.out.println();
        }
    }

    private static void rombo(int lado) {
        // Parte superior
        for (int i = 0; i <= lado; i++) {
            for (int j = 0; j <=lado - i; j++) {
                System.out.print(" ");
            }
            for (int j = lado-i; j <= lado+i; j++) {
                System.out.print("#");
            }
            System.out.println();
        }
        // Parte inferior
        for (int i = lado-1; i >= 0; i--) {
            for (int j = 0; j <=lado - i; j++) {
                System.out.print(" ");
            }
            for (int j = lado-i; j <= lado+i; j++) {
                System.out.print("#");
            }
            System.out.println();
        }
        
    }

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String figura;
        int tamanyo;

        // Recogida de argumentos
        while (entrada.hasNext()) {
            figura = entrada.next();
            tamanyo = entrada.nextInt();

            switch (figura) {
                case "cuadrado":
                    cuadrado(tamanyo);
                    break;
                case "triangulo":
                    triangulo(tamanyo);
                    break;
                case "rombo":
                    rombo(tamanyo);
                    break;
                default:
                    System.err.println("Error: Figura desconocida");
            }
        }
    }
}
