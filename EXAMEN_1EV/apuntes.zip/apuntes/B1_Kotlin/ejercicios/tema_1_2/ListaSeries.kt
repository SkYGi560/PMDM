   series.add(
        Serie(
            111,
            "Orphan Black",
            5,
            10,
            5,
            9,
            false,
            Genero.FICCION,
            "Graeme Manson y John Fawcett"
        )
    )
    series.add(
        Serie(
            112,
            "The Good Wife",
            7,
            22,
            2,
            1,
            false,
            Genero.DRAMA,
            "Michelle King y Robert King"
        )
    )
    series.add(
        Serie(
            113,
            "The Outsider",
            1,
            10,
            1,
            5,
            false,
            Genero.TERROR,
            "Jason Bateman, Andrew Bernstein y Igor Martinovic"
        )
    )
    series.add(
        Serie(
            114,
            "The 100",
            7,
            15,
            2,
            8,
            false,
            Genero.FICCION,
            "Jason Rothenberg"
        )
    )