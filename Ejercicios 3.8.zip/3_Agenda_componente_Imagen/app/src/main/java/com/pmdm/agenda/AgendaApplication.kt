package com.pmdm.agenda

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AgendaApplication : Application()