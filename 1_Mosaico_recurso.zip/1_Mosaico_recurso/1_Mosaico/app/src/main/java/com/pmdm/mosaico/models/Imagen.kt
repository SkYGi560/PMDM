package com.pmdm.mosaico.models

data class Imagen(val url: String = "")
