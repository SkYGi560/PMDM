package com.pmdm.mosaico.data

import com.pmdm.mosaico.data.mock.imagen.ImagenMock
import com.pmdm.mosaico.model.Imagen

fun Imagen.toImageMock(): ImagenMock = ImagenMock(
    url = this.url
)

fun ImagenMock.toImagen(): Imagen = Imagen(
    url = this.url
)
