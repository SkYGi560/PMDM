package com.pmdm.mosaico.data

import com.pmdm.mosaico.data.mock.imagen.ImagenDaoMock
import com.pmdm.mosaico.model.Imagen

class ImagenRepository {
    val imagenDaoMock = ImagenDaoMock()

    fun getImagenes(): List<Imagen> = imagenDaoMock.getImagenes().map { it.toImagen() }
}


