package com.iesdoctorbalmis.spring.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ZonaPublicaController {
    @GetMapping({"/", "/index"})
    public String inicio() {
        return "index"; 
    }
}
