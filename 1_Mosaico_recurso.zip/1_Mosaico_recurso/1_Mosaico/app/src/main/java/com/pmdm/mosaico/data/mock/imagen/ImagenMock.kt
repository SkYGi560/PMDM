package com.pmdm.mosaico.data.mock.imagen

data class ImagenMock(val url: String = "")
